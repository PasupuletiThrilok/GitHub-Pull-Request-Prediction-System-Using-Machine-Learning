import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Tuple, Dict, List
import warnings
warnings.filterwarnings('ignore')

class PROutcomePredictor:
    def __init__(self):
        self.models = {}
        self.scaler = StandardScaler()
        self.feature_importance = {}
        
    def load_data(self, csv_path: str) -> pd.DataFrame:
        """Load the extracted features"""
        print(f"Loading data from {csv_path}...")
        df = pd.read_csv(csv_path)
        print(f"Loaded {len(df)} PRs with {len(df.columns)} features")
        return df
    
    def prepare_data(self, df: pd.DataFrame, target_column: str = 'is_merged') -> Tuple[pd.DataFrame, pd.Series]:
        """Prepare features and target for ML"""
        print("\nPreparing data for ML...")
        
        # Remove non-numeric and identifier columns
        exclude_columns = ['author', 'pr_number', target_column]
        feature_columns = [col for col in df.columns if col not in exclude_columns]
        
        X = df[feature_columns].copy()
        y = df[target_column].copy()
        
        # Handle missing values
        X = X.fillna(0)
        
        print(f"Features shape: {X.shape}")
        print(f"Target distribution:")
        print(f"  - Merged: {y.sum()} PRs ({y.mean()*100:.1f}%)")
        print(f"  - Not merged: {len(y) - y.sum()} PRs ({(1-y.mean())*100:.1f}%)")
        
        return X, y
    
    def analyze_features(self, X: pd.DataFrame, y: pd.Series) -> Dict:
        """Analyze feature importance and correlations"""
        print("\nAnalyzing feature importance...")
        
        # Calculate correlations with target
        correlations = []
        for col in X.columns:
            try:
                corr = X[col].corr(y)
                if not np.isnan(corr):
                    correlations.append((col, abs(corr), corr))
            except:
                correlations.append((col, 0, 0))
        
        # Sort by absolute correlation
        correlations.sort(key=lambda x: x[1], reverse=True)
        
        print("\nTop 10 features by correlation with merge outcome:")
        for i, (feature, abs_corr, corr) in enumerate(correlations[:10]):
            direction = "(+)" if corr > 0 else "(-)"
            print(f"  {i+1:2d}. {feature:25s} {direction} {abs_corr:.3f}")
        
        return {
            'correlations': correlations,
            'top_features': [item[0] for item in correlations[:10]]
        }
    
    def train_models(self, X: pd.DataFrame, y: pd.Series) -> Dict:
        """Train multiple ML models"""
        print("\nTraining ML models...")
        
        # Define models to try
        models_to_train = {
            'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42, max_depth=5),
            'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000)
        }
        
        results = {}
        
        for name, model in models_to_train.items():
            print(f"\nTraining {name}...")
            
            # For small datasets, use all data for training and cross-validation for evaluation
            if name == 'Logistic Regression':
                # Scale features for logistic regression
                X_scaled = self.scaler.fit_transform(X)
                X_to_use = X_scaled
            else:
                X_to_use = X
            
            # Fit the model
            model.fit(X_to_use, y)
            
            # Cross-validation scores (with small dataset, use fewer folds)
            cv_folds = min(3, len(y))  # Use fewer folds for small datasets
            cv_scores = cross_val_score(model, X_to_use, y, cv=cv_folds, scoring='accuracy')
            
            # Predictions on training data (since dataset is small)
            y_pred = model.predict(X_to_use)
            accuracy = accuracy_score(y, y_pred)
            
            results[name] = {
                'model': model,
                'cv_scores': cv_scores,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'train_accuracy': accuracy,
                'predictions': y_pred
            }
            
            print(f"  Cross-validation accuracy: {cv_scores.mean():.3f} (±{cv_scores.std():.3f})")
            print(f"  Training accuracy: {accuracy:.3f}")
            
            # Feature importance for Random Forest
            if hasattr(model, 'feature_importances_'):
                importance = list(zip(X.columns, model.feature_importances_))
                importance.sort(key=lambda x: x[1], reverse=True)
                self.feature_importance[name] = importance
                
                print(f"  Top 5 important features:")
                for feat, imp in importance[:5]:
                    print(f"    - {feat}: {imp:.3f}")
        
        self.models = {name: result['model'] for name, result in results.items()}
        return results
    
    def evaluate_best_model(self, results: Dict, X: pd.DataFrame, y: pd.Series) -> str:
        """Find and evaluate the best model"""
        print("\nModel Comparison:")
        print("-" * 50)
        
        best_model_name = None
        best_score = -1
        
        for name, result in results.items():
            cv_score = result['cv_mean']
            print(f"{name:20s}: CV={cv_score:.3f} (±{result['cv_std']:.3f})")
            
            if cv_score > best_score:
                best_score = cv_score
                best_model_name = name
        
        print(f"\nBest model: {best_model_name} (CV accuracy: {best_score:.3f})")
        
        # Detailed evaluation of best model
        best_result = results[best_model_name]
        y_pred = best_result['predictions']
        
        print(f"\nDetailed evaluation of {best_model_name}:")
        print("Confusion Matrix:")
        cm = confusion_matrix(y, y_pred)
        print(cm)
        
        print("\nClassification Report:")
        print(classification_report(y, y_pred, target_names=['Not Merged', 'Merged']))
        
        return best_model_name
    
    def predict_new_pr(self, best_model_name: str, features: Dict) -> Dict:
        """Predict outcome for a new PR"""
        model = self.models[best_model_name]
        
        # Create feature vector (this would need to match your feature extraction)
        # For demo purposes, using dummy values
        print(f"\nPredicting with {best_model_name}...")
        print("Note: This is a demo - you'd need to extract features for new PRs")
        
        return {"prediction": "This would contain actual predictions"}
    
    def generate_insights(self, df: pd.DataFrame, results: Dict) -> Dict:
        """Generate insights for research paper"""
        insights = {
            'dataset_stats': {
                'total_prs': len(df),
                'merged_rate': df['is_merged'].mean(),
                'avg_review_count': df['review_count'].mean(),
                'avg_time_to_close': df['time_to_close_hours'].mean()
            },
            'model_performance': {},
            'key_findings': []
        }
        
        # Model performance summary
        for name, result in results.items():
            insights['model_performance'][name] = {
                'cv_accuracy': result['cv_mean'],
                'cv_std': result['cv_std']
            }
        
        # Key findings based on feature importance
        if 'Random Forest' in self.feature_importance:
            top_features = self.feature_importance['Random Forest'][:5]
            insights['key_findings'] = [
                f"Most important feature: {top_features[0][0]} (importance: {top_features[0][1]:.3f})",
                f"Total features analyzed: {len(df.columns)}",
                f"Cross-validation accuracy achieved: {max(r['cv_mean'] for r in results.values()):.3f}"
            ]
        
        return insights

# Main execution
if __name__ == "__main__":
    # Initialize predictor
    predictor = PROutcomePredictor()
    
    # Load data
    df = predictor.load_data('data/processed/extracted_features.csv')
    
    # Prepare data
    X, y = predictor.prepare_data(df)
    
    # Analyze features
    feature_analysis = predictor.analyze_features(X, y)
    
    # Train models
    results = predictor.train_models(X, y)
    
    # Evaluate and find best model
    best_model = predictor.evaluate_best_model(results, X, y)
    
    # Generate insights for research
    insights = predictor.generate_insights(df, results)
    
    print("\n" + "="*60)
    print("RESEARCH INSIGHTS FOR YOUR PAPER")
    print("="*60)
    
    print(f"\nDataset Statistics:")
    for key, value in insights['dataset_stats'].items():
        if isinstance(value, float):
            print(f"  - {key}: {value:.2f}")
        else:
            print(f"  - {key}: {value}")
    
    print(f"\nModel Performance:")
    for model, perf in insights['model_performance'].items():
        print(f"  - {model}: {perf['cv_accuracy']:.3f} (±{perf['cv_std']:.3f})")
    
    print(f"\nKey Findings:")
    for finding in insights['key_findings']:
        print(f"  - {finding}")
    
    print("  1. [DONE] Feature extraction completed (34 features)")
    print("  2. [DONE] Baseline ML models trained")
    print("  3. [TODO] Collect more data for robust evaluation")