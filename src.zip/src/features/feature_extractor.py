import json
import pandas as pd
from datetime import datetime
import re
from typing import List, Dict, Any
import numpy as np

class FeatureExtractor:
    def __init__(self):
        self.features = []
        
    def load_pr_data(self, json_file_path: str) -> List[Dict]:
        """Load PR data from JSON file"""
        try:
            # Try UTF-8 first
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except UnicodeDecodeError:
            # If UTF-8 fails, try with error handling
            with open(json_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                data = json.load(f)
        except Exception as e:
            print(f"Error loading JSON file: {e}")
            return []
        return data
    
    def extract_temporal_features(self, pr: Dict) -> Dict:
        """Extract time-based features"""
        features = {}
        
        try:
            # Parse timestamps - handle different formats
            created_str = pr.get('created_at', '')
            updated_str = pr.get('updated_at', '')
            
            if created_str:
                created = datetime.fromisoformat(created_str.replace('Z', '+00:00'))
                features['created_day_of_week'] = created.weekday()  # 0=Monday, 6=Sunday
                features['created_hour'] = created.hour
            else:
                features['created_day_of_week'] = -1
                features['created_hour'] = -1
                return features
            
            if updated_str:
                updated = datetime.fromisoformat(updated_str.replace('Z', '+00:00'))
                # Time between creation and last update
                features['time_to_last_update_hours'] = (updated - created).total_seconds() / 3600
            else:
                features['time_to_last_update_hours'] = 0
            
            # Time to close/merge
            closed_str = pr.get('closed_at')
            if closed_str:
                closed = datetime.fromisoformat(closed_str.replace('Z', '+00:00'))
                features['time_to_close_hours'] = (closed - created).total_seconds() / 3600
            else:
                features['time_to_close_hours'] = None
                
        except Exception as e:
            print(f"Error parsing timestamps for PR {pr.get('pr_number', 'unknown')}: {e}")
            features.update({
                'time_to_close_hours': None,
                'time_to_last_update_hours': 0,
                'created_day_of_week': -1,
                'created_hour': -1
            })
        
        return features
    
    def extract_code_features(self, pr: Dict) -> Dict:
        """Extract code-related features"""
        features = {}
        
        # Basic code metrics
        features['total_additions'] = pr.get('additions', 0)
        features['total_deletions'] = pr.get('deletions', 0)
        features['total_changes'] = features['total_additions'] + features['total_deletions']
        features['changed_files_count'] = pr.get('changed_files', 0)
        
        # File-level analysis
        files = pr.get('files', [])
        features['files_count'] = len(files)
        
        if files:
            # File type analysis
            file_extensions = []
            file_sizes = []
            
            for file_info in files:
                filename = file_info.get('filename', '')
                
                # Extract file extension
                if '.' in filename:
                    ext = filename.split('.')[-1].lower()
                    file_extensions.append(ext)
                
                # File size (changes)
                file_changes = file_info.get('changes', 0)
                file_sizes.append(file_changes)
            
            # File type diversity
            features['unique_file_types'] = len(set(file_extensions))
            features['has_python_files'] = 1 if 'py' in file_extensions else 0
            features['has_javascript_files'] = 1 if any(ext in file_extensions for ext in ['js', 'jsx', 'ts', 'tsx']) else 0
            features['has_config_files'] = 1 if any(ext in file_extensions for ext in ['yml', 'yaml', 'json', 'xml']) else 0
            features['has_documentation'] = 1 if any(ext in file_extensions for ext in ['md', 'rst', 'txt']) else 0
            
            # Size metrics
            features['avg_file_size'] = np.mean(file_sizes) if file_sizes else 0
            features['max_file_size'] = max(file_sizes) if file_sizes else 0
            features['min_file_size'] = min(file_sizes) if file_sizes else 0
        else:
            # No files data
            features.update({
                'unique_file_types': 0,
                'has_python_files': 0,
                'has_javascript_files': 0,
                'has_config_files': 0,
                'has_documentation': 0,
                'avg_file_size': 0,
                'max_file_size': 0,
                'min_file_size': 0
            })
        
        return features
    
    def extract_pr_metadata_features(self, pr: Dict) -> Dict:
        """Extract PR metadata features"""
        features = {}
        
        # Basic PR info
        features['pr_number'] = pr.get('pr_number', 0)
        features['title_length'] = len(pr.get('title', ''))
        features['body_length'] = len(pr.get('body', ''))
        features['has_body'] = 1 if pr.get('body', '').strip() else 0
        
        # PR state
        features['is_merged'] = 1 if pr.get('merged_at') else 0
        features['is_closed'] = 1 if pr.get('state') == 'closed' else 0
        
        # Author info
        features['author'] = pr.get('user', 'unknown')
        
        # Title analysis (simple text features)
        title = pr.get('title', '').lower()
        features['title_has_fix'] = 1 if 'fix' in title else 0
        features['title_has_bug'] = 1 if 'bug' in title else 0
        features['title_has_feature'] = 1 if any(word in title for word in ['feature', 'add', 'new']) else 0
        features['title_has_test'] = 1 if 'test' in title else 0
        features['title_has_docs'] = 1 if any(word in title for word in ['doc', 'readme', 'documentation']) else 0
        
        return features
    
    def extract_review_features(self, pr: Dict) -> Dict:
        """Extract review-related features"""
        features = {}
        
        reviews = pr.get('reviews', [])
        features['review_count'] = len(reviews)
        features['has_reviews'] = 1 if reviews else 0
        
        if reviews:
            # Review analysis would go here
            # For now, just basic counts
            review_states = [review.get('state', '') for review in reviews]
            features['approved_reviews'] = review_states.count('APPROVED')
            features['requested_changes'] = review_states.count('CHANGES_REQUESTED')
            features['commented_reviews'] = review_states.count('COMMENTED')
        else:
            features.update({
                'approved_reviews': 0,
                'requested_changes': 0,
                'commented_reviews': 0
            })
        
        return features
    
    def extract_all_features(self, pr: Dict) -> Dict:
        """Extract all features for a single PR"""
        all_features = {}
        
        # Combine all feature types
        all_features.update(self.extract_temporal_features(pr))
        all_features.update(self.extract_code_features(pr))
        all_features.update(self.extract_pr_metadata_features(pr))
        all_features.update(self.extract_review_features(pr))
        
        return all_features
    
    def create_feature_dataset(self, json_file_path: str) -> pd.DataFrame:
        """Create a complete feature dataset from JSON file"""
        print("Loading PR data...")
        pr_data = self.load_pr_data(json_file_path)
        
        print(f"Extracting features for {len(pr_data)} PRs...")
        feature_list = []
        
        for i, pr in enumerate(pr_data):
            print(f"Processing PR {i+1}/{len(pr_data)}: {pr.get('pr_number', 'unknown')}")
            try:
                features = self.extract_all_features(pr)
                feature_list.append(features)
            except Exception as e:
                print(f"Error processing PR {pr.get('pr_number', 'unknown')}: {e}")
                continue
        
        # Create DataFrame
        df = pd.DataFrame(feature_list)
        print(f"Feature extraction complete! Created {len(df)} rows with {len(df.columns)} features")
        
        return df
    
    def get_feature_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary statistics of extracted features"""
        summary = {
            'total_prs': len(df),
            'feature_count': len(df.columns),
            'features_with_nulls': df.isnull().sum().sum(),
            'merged_prs': df['is_merged'].sum() if 'is_merged' in df.columns else 0,
            'prs_with_reviews': df['has_reviews'].sum() if 'has_reviews' in df.columns else 0,
        }
        
        return summary

# Usage example
if __name__ == "__main__":
    # Initialize feature extractor
    extractor = FeatureExtractor()
    
    # Extract features from your JSON file
    df = extractor.create_feature_dataset('data/raw/psf_requests_prs_20250728_231256.json')
    
    # Display results
    print("\n" + "="*50)
    print("FEATURE EXTRACTION RESULTS")
    print("="*50)
    
    # Show feature summary
    summary = extractor.get_feature_summary(df)
    for key, value in summary.items():
        print(f"{key}: {value}")
    
    print(f"\nExtracted Features:")
    for col in sorted(df.columns):
        print(f"  - {col}")
    
    # Show first few rows
    print(f"\nFirst 3 rows of features:")
    print(df.head(3))
    
    # Save features to CSV
    output_file = 'data/processed/extracted_features.csv'
    df.to_csv(output_file, index=False)
    print(f"\nFeatures saved to: {output_file}")