import requests
import pandas as pd
import json
import time
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# Configuration
GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
GITHUB_API_BASE = 'https://api.github.com'
TARGET_REPOS = [
    'flask/flask',
    'django/django', 
    'scikit-learn/scikit-learn',
    'pandas-dev/pandas',
    'psf/requests'
]
RAW_DATA_PATH = 'data/raw/'

class GitHubDataCollector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'token {GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json'
        })
        self.base_url = GITHUB_API_BASE
        
    def check_rate_limit(self):
        """Check GitHub API rate limit status"""
        response = self.session.get(f'{self.base_url}/rate_limit')
        if response.status_code == 200:
            data = response.json()
            remaining = data['resources']['core']['remaining']
            reset_time = data['resources']['core']['reset']
            print(f"Rate limit: {remaining} requests remaining")
            print(f"Resets at: {datetime.fromtimestamp(reset_time)}")
            return remaining > 100  # Keep buffer of 100 requests
        return False
    
    def get_pull_requests(self, repo, state='closed', per_page=30, max_pages=2):
        """Collect pull requests from a repository"""
        pulls = []
        print(f"Collecting pull requests from {repo}...")
        
        for page in range(1, max_pages + 1):
            if not self.check_rate_limit():
                print("Rate limit low, waiting...")
                time.sleep(60)
                
            url = f'{self.base_url}/repos/{repo}/pulls'
            params = {
                'state': state,
                'per_page': per_page,
                'page': page,
                'sort': 'created',  # Fixed: changed from 'updated'
                'direction': 'desc'
            }
            
            print(f"Requesting: {url} with params: {params}")
            response = self.session.get(url, params=params)
            
            if response.status_code == 200:
                page_pulls = response.json()
                if not page_pulls:  # No more data
                    print("  No more pull requests found")
                    break
                pulls.extend(page_pulls)
                print(f"  Page {page}: {len(page_pulls)} pull requests")
                time.sleep(0.2)  # Be respectful to API
            else:
                print(f"Error {response.status_code}: {response.text}")
                if response.status_code == 404:
                    print("Repository might not exist or be accessible")
                break
                
        print(f"Total collected: {len(pulls)} pull requests")
        return pulls
    
    def get_pull_request_reviews(self, repo, pr_number):
        """Get reviews for a specific pull request"""
        url = f'{self.base_url}/repos/{repo}/pulls/{pr_number}/reviews'
        response = self.session.get(url)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            print(f"  Reviews not found for PR #{pr_number}")
            return []
        else:
            print(f"  Error getting reviews for PR #{pr_number}: {response.status_code}")
            return []
    
    def get_pull_request_files(self, repo, pr_number):
        """Get changed files for a specific pull request"""
        url = f'{self.base_url}/repos/{repo}/pulls/{pr_number}/files'
        response = self.session.get(url)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            print(f"  Files not found for PR #{pr_number}")
            return []
        else:
            print(f"  Error getting files for PR #{pr_number}: {response.status_code}")
            return []
    
    def collect_detailed_pr_data(self, repo, max_prs=20):
        """Collect detailed data for pull requests including reviews and files"""
        print(f"\n=== Collecting detailed data for {repo} ===")
        
        # First get basic PR info
        pulls = self.get_pull_requests(repo, per_page=max_prs, max_pages=1)
        
        if not pulls:
            print(f"No pull requests found for {repo}")
            return []
        
        detailed_data = []
        
        for i, pr in enumerate(pulls[:max_prs]):
            print(f"Processing PR {i+1}/{min(len(pulls), max_prs)}: #{pr['number']}")
            
            # Get reviews (with error handling)
            reviews = self.get_pull_request_reviews(repo, pr['number'])
            
            # Get changed files (with error handling)
            files = self.get_pull_request_files(repo, pr['number'])
            
            # Combine all data
            pr_data = {
                'repo': repo,
                'pr_number': pr['number'],
                'title': pr['title'],
                'body': pr['body'] if pr['body'] else "",
                'state': pr['state'],
                'created_at': pr['created_at'],
                'updated_at': pr['updated_at'],
                'closed_at': pr['closed_at'],
                'merged_at': pr['merged_at'],
                'user': pr['user']['login'],
                'additions': pr.get('additions', 0),
                'deletions': pr.get('deletions', 0),
                'changed_files': pr.get('changed_files', 0),
                'reviews': reviews,
                'files': files
            }
            
            detailed_data.append(pr_data)
            time.sleep(0.3)  # Be extra careful with rate limits
            
        return detailed_data
    
    def save_data(self, data, filename):
        """Save data to JSON file"""
        # Create directory if it doesn't exist
        if not os.path.exists(RAW_DATA_PATH):
            os.makedirs(RAW_DATA_PATH, exist_ok=True)
            print(f"Created directory: {RAW_DATA_PATH}")
        
        filepath = os.path.join(RAW_DATA_PATH, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"Data saved to {filepath}")
        return filepath

# Example usage and testing
def main():
    collector = GitHubDataCollector()
    
    # Test connection
    print("Testing GitHub API connection...")
    if collector.check_rate_limit():
        print(" GitHub API connection successful!")
    else:
        print(" GitHub API connection failed!")
        return
    
    # Start with a simpler repository that definitely has PRs
    test_repo = 'psf/requests'  # This repo definitely has many PRs
    
    try:
        # Collect detailed data
        pr_data = collector.collect_detailed_pr_data(test_repo, max_prs=10)
        
        if pr_data:
            # Save to file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{test_repo.replace('/', '_')}_prs_{timestamp}.json"
            filepath = collector.save_data(pr_data, filename)
            
            # Basic analysis
            print(f"\n=== Quick Analysis ===")
            print(f"Total PRs collected: {len(pr_data)}")
            
            merged_prs = [pr for pr in pr_data if pr['merged_at']]
            print(f"Merged PRs: {len(merged_prs)}")
            
            reviewed_prs = [pr for pr in pr_data if pr['reviews']]
            print(f"PRs with reviews: {len(reviewed_prs)}")
            
            python_files = []
            for pr in pr_data:
                for file in pr['files']:
                    if file['filename'].endswith('.py'):
                        python_files.append(file)
            print(f"Python files changed: {len(python_files)}")
            
            print(f"\n SUCCESS! Your first dataset is ready at: {filepath}")
            
        else:
            print("No data collected. Let's try a different repository.")
            
    except Exception as e:
        print(f"Error during data collection: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()